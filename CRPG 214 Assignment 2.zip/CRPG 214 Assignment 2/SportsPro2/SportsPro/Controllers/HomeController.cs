﻿using AspNetCore;
using Microsoft.AspNetCore.Mvc;

namespace SportsPro.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //[Route("About")]    // Add Routing attribute to shortern the URL
        public IActionResult About()
        {
            return View();
        }
    }
}